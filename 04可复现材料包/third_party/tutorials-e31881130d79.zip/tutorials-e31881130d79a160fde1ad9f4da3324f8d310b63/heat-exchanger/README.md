---
title: Heat exchanger
permalink: tutorials-heat-exchanger.html
aliases:
  - /tutorials-heat-exchanger.html
keywords: CHT, OpenFOAM, CalculiX
summary: Tutorial for a shell-and-tube heat exchanger, using OpenFOAM and CalculiX
---

{% note %}
Get the [case files of this tutorial](https://github.com/precice/tutorials/tree/develop/heat-exchanger), as continuously rendered here, or see the [latest released version](https://github.com/precice/tutorials/tree/master/heat-exchanger) (if there is already one). Read how in the [tutorials introduction](https://precice.org/tutorials.html).
{% endnote %}

{% tip %}
This is one of our first ever and most popular tutorials, yet definitely not the simplest or quickest to run. If you are looking for a CHT tutorial with multiple participants, better start from the [simplified heat exchanger](https://precice.org/tutorials-heat-exchanger-simplified.html). An important difference is that the simplified version uses a multi-implicit coupling scheme, instead of composing explicit schemes.
{% endtip  %}

This tutorial describes how to run a conjugate heat transfer simulation with two separate OpenFOAM solvers and CalculiX. The files for this tutorial are located in this repository (directory CHT/heat_exchanger).

This tutorial is based on [a case](https://www.simscale.com/projects/cheunglucia/heat_exchanger_-_cht_simulation/) prepared with [SimScale](https://www.simscale.com/) by [Lucia Cheung Yau](https://github.com/ludcila) for her [Master's Thesis](https://mediatum.ub.tum.de/1461907).

## Setup

This scenario consists of two fluid and one solid participant and represents a [shell-and-tube heat exchanger](https://en.wikipedia.org/wiki/Shell_and_tube_heat_exchanger). The geometry includes an (adiabatic) shell, in which an _inner fluid_ flows. It enters from the top-right inlet and exits from the bottom-left, after getting redirected several times by baffles. The geometry also includes a set of tubes, in which an _outer fluid_ flows from left to right. The two fluids enter in different temperatures and exchange heat through the (thick) solid walls of the tubes. This is a steady-state simulation and the flow is considered laminar.

![Shell-and-tube heat exchanger geometry](images/tutorials-heat-exchanger-geometry.png)

We define the participants `Inner-Fluid`, `Solid`, and `Outer-Fluid` and two interfaces: one between the `Inner-Fluid` and `Solid` and one between the `Solid` and `Outer-Fluid`. Parallel-explicit coupling is used on both interfaces as pseudo timestepping to reach steady-state. We use nearest-neighbor mapping between all meshes. The OpenFOAM participants can either be executed in serial, or in parallel.

![Heat exchanger: three participants](images/tutorials-heat-exchanger-participants.png)

## Configuration

preCICE configuration (image generated using the [precice-config-visualizer](https://precice.org/tooling-config-visualization.html)):

![preCICE configuration visualization](images/tutorials-heat-exchanger-precice-config.png)

## Available solvers

* OpenFOAM. `buoyantSimpleFoam` is used for fluid flow (both participants). This is a solver for steady-state, buoyant, turbulent flow of compressible fluids for ventilation and heat transfer. For more information, have a look at the [OpenFOAM adapter documentation](https://precice.org/adapter-openfoam-overview.html).

* CalculiX. For more information, have a look at the [CalculiX adapter documentation](https://precice.org/adapter-calculix-overview.html).

## Running the Simulation

{% note %}
Since the already prepared case contains mesh files of approx. 50MB in size, we currently host these files outside of the tutorials repository and are downloaded automatically the first time.
{% endnote %}

In order to run the coupled simulation, you can simply step into the participant directories and execute`./run.sh` (or `./run.sh -parallel` for running a fluid participant in parallel). The simulation will need several minutes or up to an hour on a laptop to end (t=500). Before repeating the simulation, you can use the `clean-tutorial.sh` script to clean-up any previous results and log files.

## Post-processing

After the first results are written (a new time directory will be created), you may visualize the results.

For the OpenFOAM results, you can use ParaView and open the already-provided `fluid-inner-openfoam.foam` and `fluid-outer-openfoam.foam` files. You can then group the two cases and visualize them together.

Unfortunately, ParaView does not support CalculiX result files. You may see the results in CGX or convert them using 3rd-party tools.

![The heat exchanger with streamlines](images/tutorials-heat-exchanger-visualization.png)

{% disclaimer %}
This offering is not approved or endorsed by OpenCFD Limited, producer and distributor of the OpenFOAM software via www.openfoam.com, and owner of the OPENFOAM®  and OpenCFD®  trade marks.
{% enddisclaimer %}
